from controller import Robot

def run_robot():
    robot = Robot()
    timestep = int(robot.getBasicTimeStep())

    # 取得馬達元件
    motor = robot.getDevice("motor0")
    motor.setPosition(float('inf'))  # 無限旋轉
    motor.setVelocity(1.0)           # 順時針轉速，數值越大越快

    # 主迴圈
    while robot.step(timestep) != -1:
        pass  # 目前不做其他操作，馬達會持續轉

if __name__ == "__main__":
    run_robot()
